import Search from "../containers/Search/Search";

const App = () => {
  return (
    <>
      <Search />;
    </>
  );
};

export default App;
