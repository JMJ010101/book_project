import React from "react";
import LoginPage from "../containers/Login/LoginPage";

const Login = () => {
  return (
    <>
      <LoginPage />
    </>
  );
};

export default Login;
