import React from "react";
import IntroForm from "../containers/Intro/IntroForm";

const Intro = () => {
  return (
    <>
      <IntroForm />
    </>
  );
};

export default Intro;
