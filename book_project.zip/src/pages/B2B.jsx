import React from "react";
import B2BForm from "../containers/B2B/B2BForm";

const B2B = () => {
  return (
    <>
      <B2BForm />
    </>
  );
};

export default B2B;
