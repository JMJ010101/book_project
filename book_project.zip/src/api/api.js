const apiServer = "http://192.168.0.66:8088";
export default apiServer;
