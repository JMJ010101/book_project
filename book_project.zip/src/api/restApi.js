const getApiKey = () => {
  return "37138d0e18d1a1d87e8da3a2c2c5bf96";
};

export default getApiKey;
